<template>
    <div class="max-w-md mx-auto p-6 space-y-6">
        <h1 class="text-3xl font-bold">Create an OptionsX account</h1>

        <p class="text-gray-600">
            Already have an OptionsX account?
            <a href="#" class="text-blue-600 hover:text-blue-800">Sign in</a>
        </p>

        <div class="space-y-4">
            <h2 class="text-xl font-semibold">As a Creator, you can:</h2>

            <ul class="space-y-3">
                <li class="flex items-center space-x-2">
                    <span class="text-xl">🎨</span>
                    <span>Access diverse themes, videos, and photos.</span>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="text-xl">💰</span>
                    <span>Sell your creative work and earn money.</span>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="text-xl">🔒</span>
                    <span>Enjoy secure and seamless transactions.</span>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="text-xl">🌍</span>
                    <span>Connect with a global creative community.</span>
                </li>
            </ul>
        </div>

        <div class="pt-4">
            <h2 class="text-2xl font-bold">Start your journey today!</h2>
        </div>
    </div>
</template>

<script setup>
// No reactive state or methods needed for this component currently,
// but we can add them here when needed
</script>
