<script setup>
// No data needed for this component
</script>

<template>
  <div class="bg-gray-500 py-16 px-4">
    <div class="max-w-4xl  mx-auto text-center">
      <!-- Header -->
      <h2 class="text-4xl font-bold text-white mb-4">
        Boost your interests to new heights.
      </h2>

      <!-- Description -->
      <p class="text-gray-200 text-lg mb-8">
        Join a vibrant, dynamic creative community and pursue your passion for a living.
      </p>

      <!-- CTA Button -->
      <button class="bg-red-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-red-700 transition-colors">
        Be a creator for OptionsX now.
      </button>
    </div>
  </div>
</template>