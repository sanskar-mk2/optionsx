<template>
    <div class="max-w-md mx-auto p-6 space-y-6">
        <div class="space-y-2">
            <h1 class="text-3xl font-bold">Welcome back to OptionsX!</h1>
            <p class="text-gray-600">
                Don't have an account?
                <a
                    href="#"
                    class="text-blue-600 hover:text-blue-800 font-medium"
                    >Create OptionsX account</a
                >
            </p>
        </div>

        <div class="space-y-4">
            <h2 class="text-xl font-semibold">As a Creator, you can:</h2>

            <ul class="space-y-3">
                <li class="flex items-center space-x-2">
                    <span class="text-xl">🎨</span>
                    <span>Access diverse themes, videos, and photos.</span>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="text-xl">💰</span>
                    <span>Sell your creative work and earn money.</span>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="text-xl">🔒</span>
                    <span>Enjoy secure and seamless transactions.</span>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="text-xl">🌍</span>
                    <span>Connect with a global creative community.</span>
                </li>
            </ul>
        </div>
    </div>
</template>

<script setup>
// You can add any required logic here
const navigateToSignup = () => {
    // Handle navigation to signup page
};
</script>
